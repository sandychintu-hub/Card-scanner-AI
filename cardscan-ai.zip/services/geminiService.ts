
import { GoogleGenAI, Type } from "@google/genai";
import { AIExtractionResult } from "../types";

export const extractContactFromImage = async (base64Image: string): Promise<AIExtractionResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Image.split(",")[1] || base64Image,
          },
        },
        {
          text: "Extract all contact information from this business card. Note: There might be a QR code on the card; if you can decode it or see vCard information, prioritize that. Otherwise, extract text using OCR. Be precise. If a field is missing, leave it as an empty string. Categorize the lead based on the company or industry mentioned.",
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          firstName: { type: Type.STRING },
          lastName: { type: Type.STRING },
          organization: { type: Type.STRING },
          title: { type: Type.STRING },
          email: { type: Type.STRING },
          phone: { type: Type.STRING },
          website: { type: Type.STRING },
          address: { type: Type.STRING },
          category: { type: Type.STRING, description: "A simple industry or tag like 'Tech', 'Retail', 'Customer', etc." },
          notes: { type: Type.STRING, description: "Any extra text found on the card or decoded from QR." },
        },
        required: ["firstName", "lastName", "organization"],
      },
    },
  });

  try {
    const text = response.text || "{}";
    // Basic cleaning in case model returns markdown backticks
    const cleanedJson = text.replace(/```json\n?|\n?```/g, "").trim();
    const data = JSON.parse(cleanedJson);
    return data as AIExtractionResult;
  } catch (error) {
    console.error("Failed to parse Gemini response", error);
    throw new Error("Could not interpret card data.");
  }
};
