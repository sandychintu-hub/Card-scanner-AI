
import React from 'react';
import { Camera, FileText, Smartphone, LayoutGrid, Settings } from 'lucide-react';

export const APP_NAV_ITEMS = [
  { id: 'scan', label: 'Scan', icon: <Camera size={20} /> },
  { id: 'cards', label: 'Cards', icon: <Smartphone size={20} /> },
  { id: 'docs', label: 'Export', icon: <FileText size={20} /> },
];

export const STORAGE_KEY = 'cardscan_contacts_db';
