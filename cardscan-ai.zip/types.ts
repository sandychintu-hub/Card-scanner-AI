
export interface BusinessContact {
  id: string;
  firstName: string;
  lastName: string;
  organization: string;
  title: string;
  email: string;
  phone: string;
  website: string;
  address: string;
  notes: string;
  category: string;
  scannedAt: string;
  imageUrl?: string;
}

export interface AIExtractionResult {
  firstName: string;
  lastName: string;
  organization: string;
  title: string;
  email: string;
  phone: string;
  website: string;
  address: string;
  category: string;
  notes: string;
}
