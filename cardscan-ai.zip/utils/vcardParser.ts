
import { AIExtractionResult } from "../types";

export const parseVCard = (vcard: string): Partial<AIExtractionResult> => {
  const result: Partial<AIExtractionResult> = {
    firstName: "",
    lastName: "",
    organization: "",
    title: "",
    email: "",
    phone: "",
    website: "",
    address: "",
    category: "QR Contact",
    notes: ""
  };

  const lines = vcard.split(/\r?\n/);
  
  lines.forEach(line => {
    const [key, ...values] = line.split(':');
    if (!key || values.length === 0) return;
    
    const value = values.join(':').trim();
    const cleanKey = key.split(';')[0].toUpperCase();

    switch (cleanKey) {
      case 'FN':
        const names = value.split(' ');
        result.firstName = names[0] || "";
        result.lastName = names.slice(1).join(' ') || "";
        break;
      case 'N':
        const nParts = value.split(';');
        result.lastName = nParts[0] || result.lastName;
        result.firstName = nParts[1] || result.firstName;
        break;
      case 'ORG':
        result.organization = value.replace(/;/g, ' ').trim();
        break;
      case 'TITLE':
        result.title = value;
        break;
      case 'EMAIL':
        result.email = value;
        break;
      case 'TEL':
        result.phone = value;
        break;
      case 'URL':
        result.website = value;
        break;
      case 'ADR':
        result.address = value.replace(/;/g, ' ').trim();
        break;
      case 'NOTE':
        result.notes = value;
        break;
    }
  });

  return result;
};

export const isVCard = (data: string): boolean => {
  return data.toUpperCase().includes('BEGIN:VCARD');
};
