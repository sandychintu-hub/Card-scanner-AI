
import { BusinessContact } from "../types";

export const generateVCard = (contact: BusinessContact): string => {
  const lines = [
    "BEGIN:VCARD",
    "VERSION:3.0",
    `FN:${contact.firstName} ${contact.lastName}`,
    `N:${contact.lastName};${contact.firstName};;;`,
    `ORG:${contact.organization}`,
    `TITLE:${contact.title}`,
    `EMAIL;TYPE=INTERNET,WORK:${contact.email}`,
    `TEL;TYPE=WORK,VOICE:${contact.phone}`,
    `ADR;TYPE=WORK:;;${contact.address.replace(/\n/g, ";")}`,
    `URL:${contact.website}`,
    `NOTE:${contact.notes} (Imported via CardScan AI)`,
    "END:VCARD"
  ];
  return lines.join("\n");
};

export const downloadVCard = (contact: BusinessContact) => {
  const vcard = generateVCard(contact);
  const blob = new Blob([vcard], { type: "text/vcard" });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", `${contact.firstName}_${contact.lastName}.vcf`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
