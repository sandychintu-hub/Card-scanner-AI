
import React from 'react';
import { BusinessContact } from '../types';
import { Mail, Phone, Globe, MapPin, Download, Trash2, Building2, UserCircle } from 'lucide-react';
import { downloadVCard } from '../utils/vcard';

interface ContactCardProps {
  contact: BusinessContact;
  onDelete: (id: string) => void;
}

const ContactCard: React.FC<ContactCardProps> = ({ contact, onDelete }) => {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition-shadow group">
      <div className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center font-bold text-xl">
              {contact.firstName[0]}{contact.lastName[0]}
            </div>
            <div>
              <h3 className="font-bold text-lg text-slate-800 leading-tight">
                {contact.firstName} {contact.lastName}
              </h3>
              <p className="text-sm text-slate-500 font-medium">{contact.title}</p>
            </div>
          </div>
          <span className="px-2 py-1 bg-slate-100 text-slate-600 text-xs font-semibold rounded-md uppercase tracking-wider">
            {contact.category || 'Lead'}
          </span>
        </div>

        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-3 text-slate-600">
            <Building2 size={16} className="text-slate-400 shrink-0" />
            <span className="text-sm font-medium">{contact.organization || 'No Company'}</span>
          </div>
          {contact.email && (
            <div className="flex items-center gap-3 text-slate-600">
              <Mail size={16} className="text-slate-400 shrink-0" />
              <a href={`mailto:${contact.email}`} className="text-sm hover:text-indigo-600 transition-colors truncate">
                {contact.email}
              </a>
            </div>
          )}
          {contact.phone && (
            <div className="flex items-center gap-3 text-slate-600">
              <Phone size={16} className="text-slate-400 shrink-0" />
              <a href={`tel:${contact.phone}`} className="text-sm hover:text-indigo-600 transition-colors">
                {contact.phone}
              </a>
            </div>
          )}
          {contact.address && (
            <div className="flex items-start gap-3 text-slate-600">
              <MapPin size={16} className="text-slate-400 shrink-0 mt-0.5" />
              <span className="text-sm leading-tight line-clamp-2">{contact.address}</span>
            </div>
          )}
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => downloadVCard(contact)}
            className="flex-1 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-xl text-sm font-semibold transition-colors"
          >
            <Download size={16} />
            Sync to Phone
          </button>
          <button
            onClick={() => onDelete(contact.id)}
            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
            title="Delete Contact"
          >
            <Trash2 size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ContactCard;
