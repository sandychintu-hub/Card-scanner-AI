
import React, { useState, useRef } from 'react';
import { Camera, Upload, Loader2, AlertCircle, X, QrCode, Sparkles } from 'lucide-react';
import { extractContactFromImage } from '../services/geminiService';
import { AIExtractionResult, BusinessContact } from '../types';
import jsQR from 'jsqr';
import { isVCard, parseVCard } from '../utils/vcardParser';

interface ScannerProps {
  onContactExtracted: (contact: BusinessContact) => void;
}

const Scanner: React.FC<ScannerProps> = ({ onContactExtracted }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string>("Analyzing Card...");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const tryDecodeQR = (base64: string): Promise<string | null> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(null);
        
        // Use a reasonable size for decoding to maintain performance
        const maxDim = 1024;
        let width = img.width;
        let height = img.height;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = (height / width) * maxDim;
            width = maxDim;
          } else {
            width = (width / height) * maxDim;
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(img, 0, 0, width, height);
        
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);
        resolve(code ? code.data : null);
      };
      img.onerror = () => resolve(null);
      img.src = base64;
    });
  };

  const processImage = async (base64String: string) => {
    setIsProcessing(true);
    setError(null);
    setStatusMessage("Scanning for QR Codes...");

    try {
      // 1. Try Client-side QR Decoding
      const qrData = await tryDecodeQR(base64String);
      
      if (qrData) {
        setStatusMessage("QR Code detected! Extracting...");
        
        if (isVCard(qrData)) {
          const result = parseVCard(qrData);
          const newContact: BusinessContact = {
            firstName: result.firstName || "Unknown",
            lastName: result.lastName || "",
            organization: result.organization || "",
            title: result.title || "",
            email: result.email || "",
            phone: result.phone || "",
            website: result.website || "",
            address: result.address || "",
            category: result.category || "QR Contact",
            notes: result.notes || "Imported via QR Code",
            id: crypto.randomUUID(),
            scannedAt: new Date().toISOString(),
            imageUrl: base64String,
          };
          onContactExtracted(newContact);
          setPreviewUrl(null);
          setIsProcessing(false);
          return;
        } else {
          // It's a QR but not a vCard (maybe a URL or text)
          // We let Gemini handle the image context to combine OCR + QR text
          setStatusMessage("Interpreting QR content with AI...");
        }
      }

      // 2. Fallback to Gemini AI for OCR/General extraction
      setStatusMessage("Using AI to read card details...");
      const result = await extractContactFromImage(base64String);
      
      const newContact: BusinessContact = {
        ...result,
        id: crypto.randomUUID(),
        scannedAt: new Date().toISOString(),
        imageUrl: base64String,
      };
      
      onContactExtracted(newContact);
      setPreviewUrl(null);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to process card. Please try a clearer photo.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setPreviewUrl(base64);
      processImage(base64);
    };
    reader.readAsDataURL(file);
    // Clear input so same file can be selected again if needed
    event.target.value = '';
  };

  const triggerInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full max-w-xl mx-auto mb-8">
      <div 
        className={`relative border-2 border-dashed rounded-3xl p-8 flex flex-col items-center justify-center transition-all cursor-pointer overflow-hidden ${
          isProcessing ? 'border-indigo-400 bg-indigo-50/30' : 'border-slate-300 hover:border-indigo-400 bg-white hover:bg-slate-50'
        }`}
        onClick={!isProcessing ? triggerInput : undefined}
      >
        <input 
          type="file" 
          accept="image/*" 
          capture="environment"
          className="hidden" 
          ref={fileInputRef}
          onChange={handleFileChange}
        />

        {previewUrl && isProcessing ? (
          <div className="absolute inset-0 z-0">
            <img src={previewUrl} alt="Preview" className="w-full h-full object-cover opacity-20 grayscale blur-sm" />
          </div>
        ) : null}

        <div className="relative z-10 flex flex-col items-center text-center">
          {isProcessing ? (
            <>
              <div className="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center mb-4 animate-pulse shadow-lg shadow-indigo-200">
                <Loader2 className="text-white animate-spin" size={32} />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">{statusMessage}</h3>
              <p className="text-slate-500 max-w-xs">Scanning for text, logos, and QR codes to build your contact.</p>
            </>
          ) : (
            <>
              <div className="flex gap-4 mb-4">
                <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center shadow-sm">
                  <Camera size={32} />
                </div>
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center shadow-sm">
                  <QrCode size={32} />
                </div>
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">Scan Business Card</h3>
              <p className="text-slate-500 max-w-sm mb-6">
                Point your camera at a card. We automatically detect <strong>text</strong> and <strong>QR codes</strong>.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <button className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-md active:scale-95">
                  <Camera size={20} />
                  Take Photo
                </button>
                <button className="flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-6 py-3 rounded-xl font-bold transition-all active:scale-95">
                  <Upload size={20} />
                  Upload
                </button>
              </div>
              <div className="mt-6 flex items-center gap-2 text-xs font-bold text-indigo-500 uppercase tracking-widest">
                <Sparkles size={14} />
                AI-Powered Extraction
              </div>
            </>
          )}
        </div>
      </div>

      {error && (
        <div className="mt-4 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600 animate-in fade-in slide-in-from-top-2">
          <AlertCircle size={20} className="shrink-0" />
          <p className="text-sm font-medium">{error}</p>
          <button onClick={() => setError(null)} className="ml-auto p-1 hover:bg-red-100 rounded-md transition-colors">
            <X size={16} />
          </button>
        </div>
      )}
    </div>
  );
};

export default Scanner;
