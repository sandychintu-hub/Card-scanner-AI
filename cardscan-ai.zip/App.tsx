
import React, { useState, useEffect } from 'react';
import { BusinessContact } from './types';
import Scanner from './components/Scanner';
import ContactCard from './components/ContactCard';
import { Search, Plus, Filter, Users, Download, ShieldCheck, Sparkles, BookOpen } from 'lucide-react';

const App: React.FC = () => {
  const [contacts, setContacts] = useState<BusinessContact[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  // Load from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('cardscan_contacts');
    if (saved) {
      try {
        setContacts(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load local storage contacts");
      }
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('cardscan_contacts', JSON.stringify(contacts));
  }, [contacts]);

  const handleContactExtracted = (contact: BusinessContact) => {
    setContacts(prev => [contact, ...prev]);
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to remove this contact?")) {
      setContacts(prev => prev.filter(c => c.id !== id));
    }
  };

  const categories = ['All', ...Array.from(new Set(contacts.map(c => c.category).filter(Boolean)))];

  const filteredContacts = contacts.filter(c => {
    const matchesSearch = 
      `${c.firstName} ${c.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.organization.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.category.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = activeCategory === 'All' || c.category === activeCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen pb-24 lg:pb-12">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 px-4 py-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <BookOpen size={24} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 leading-none">CardScan AI</h1>
              <p className="text-xs text-slate-500 mt-1 font-medium flex items-center gap-1">
                <Sparkles size={10} className="text-indigo-500" /> Powered by Gemini
              </p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-slate-500 bg-slate-100 px-3 py-1.5 rounded-full text-xs font-semibold">
            <ShieldCheck size={14} className="text-emerald-500" />
            Personal Storage Only
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-8 py-8">
        {/* Scanner Section */}
        <div className="mb-12">
          <Scanner onContactExtracted={handleContactExtracted} />
        </div>

        {/* List Section */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            My Contacts
            <span className="bg-slate-200 text-slate-600 text-xs px-2 py-1 rounded-full">{contacts.length}</span>
          </h2>

          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Search names or companies..."
                className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none w-full sm:w-64"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex overflow-x-auto gap-2 pb-1 no-scrollbar sm:pb-0">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
                    activeCategory === cat 
                      ? 'bg-indigo-600 text-white shadow-md' 
                      : 'bg-white border border-slate-200 text-slate-600 hover:border-indigo-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {filteredContacts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredContacts.map(contact => (
              <ContactCard key={contact.id} contact={contact} onDelete={handleDelete} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 mb-4">
              <Users size={40} />
            </div>
            <h3 className="text-xl font-bold text-slate-800 mb-1">No Contacts Found</h3>
            <p className="text-slate-500 max-w-sm">
              {contacts.length === 0 
                ? "Your library is empty. Scan a business card to start your digital collection."
                : "No contacts match your current search or filter criteria."}
            </p>
          </div>
        )}
      </main>

      {/* Floating Action Bar (Mobile Only) */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 sm:hidden">
        <button 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="bg-indigo-600 text-white px-6 py-4 rounded-full shadow-2xl shadow-indigo-400 flex items-center gap-3 font-bold active:scale-95 transition-transform"
        >
          <Plus size={24} />
          Scan New Card
        </button>
      </div>
    </div>
  );
};

export default App;
